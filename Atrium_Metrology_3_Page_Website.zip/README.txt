Atrium Metrology — 3 Page Website

Pages:
- index.html — Home, company positioning, industries and CTA
- services.html — CMM inspection, GD&T, 3D scanning, CAD comparison, reporting and workflow
- technology.html — FARO 3 metre portable CMM, PolyWorks® inspection/analysis and animated reporting visual

All animated visuals are CSS/HTML based and responsive. The supplied Atrium Metrology logo is embedded directly in each page.
Open index.html to start.
